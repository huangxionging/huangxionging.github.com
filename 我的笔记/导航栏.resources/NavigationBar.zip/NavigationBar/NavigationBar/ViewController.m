//
//  ViewController.m
//  NavigationBar
//
//  Created by huangxiong on 14-7-3.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) save:(id)sender
{
    self.label.text = @"点击了Save按钮";
}

- (IBAction) add:(id)sender
{
    self.label.text = @"点击了Add按钮";
}
@end
