//
//  ViewController.h
//  Redmann‘s browser
//
//  Created by huangxiong on 14-7-1.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import <UIKit/UIKit.h>

// 此处使用了代理协议，textFieldShouldReturn:(UITextField *)textField 这个方法在这个代理协议里面
@interface ViewController : UIViewController<UITextFieldDelegate>

// 与webView 视图控件连接，在windows中，相当于控件与控制控件的类绑定起来
@property (weak, nonatomic) IBOutlet UIWebView *webView;

// 文本控件，用来接受用户输入的网址
@property (weak, nonatomic) IBOutlet UITextField *webPath;

// 当用户点击 Go 按钮的时候会触发该动作
- (IBAction)Go:(id)sender;

// 代理协议需要实现的类，在textField 控件被点击时会被调研
-(BOOL)textFieldShouldReturn:(UITextField *)textField;

@end
