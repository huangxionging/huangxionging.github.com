//
//  ViewController.m
//  Redmann‘s browser
//
//  Created by huangxiong on 14-7-1.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 获取网址的页面，并使用webView加载页面
- (IBAction)Go:(id)sender
{
    // 获取文本控件webPath的字符串，也就是获得网址
    NSString *path = self.webPath.text;
    
    // 将字符串网址转换成地址类
    NSURL *pagePath = [NSURL URLWithString: path];
    
    // 通过地址类来发送网页请求
    NSURLRequest *request = [NSURLRequest requestWithURL: pagePath];
    
    // 网页视图控件加载请求的网页
    [self.webView loadRequest: request];
}

// 代理协议所使用的方法，使得textField 控件能够调用方法来操作
-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    // 文本控件放弃第一响应者，关闭键盘，按回车时会调用
    [self.webPath resignFirstResponder];
    
    // 当文本控件的返回键值为Go的时候，调用 GO: 方法,发送网页请求
    // 返回键值就是键盘打开后，点击 Go/return等等按钮得到的键盘返回值
    if (self.webPath.returnKeyType == UIReturnKeyGo)
    {
        [self Go: self];
    }
    return YES;
}

@end
