//
//  ViewController.h
//  Hello iOS
//
//  Created by huangxiong on 14-6-23.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kSaveKey @"UnsavedText"

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UITextField *txtField;
@property (strong, nonatomic) IBOutlet UILabel *Hello;

@property (strong, nonatomic) IBOutlet UIButton *OK;


- (IBAction)TouchDown:(id)sender;

@end
