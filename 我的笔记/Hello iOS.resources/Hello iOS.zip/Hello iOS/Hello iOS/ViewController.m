//
//  ViewController.m
//  Hello iOS
//
//  Created by huangxiong on 14-6-23.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
bool flag;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    flag = true;
    NSLog(@"%@", @"视图控制器创建成功。");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"%@", @"内存警告！");
}

// Controller's save and restore
-(void) encodeRestorableStateWithCoder:(NSCoder *)coder
{
    NSLog(@"存储过程");
    [super encodeRestorableStateWithCoder: coder];
    [coder encodeObject:self.txtField.text forKey: kSaveKey];
}

-(void) decodeRestorableStateWithCoder:(NSCoder *)coder
{
    NSLog(@"恢复过程");
    [super decodeRestorableStateWithCoder: coder];
    self.txtField.text = [coder decodeObjectForKey: kSaveKey];
}

- (IBAction)TouchDown:(id)sender
{
    NSLog(@"你点击了按钮！");
    
    if (flag == true)
    {
        self.Hello.text = @"you are so good!";
        self.txtField.text = @"Oh my god！！！";
        flag = false;
    }
    else if (flag == false)
    {
        self.Hello.text = @"English!";
        self.txtField.text = @"廖斌是个好人，O(∩_∩)O哈哈~";
        flag = true;
    }
   
}
@end
