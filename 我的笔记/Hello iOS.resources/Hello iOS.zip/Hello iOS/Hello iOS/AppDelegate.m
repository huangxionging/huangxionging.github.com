//
//  AppDelegate.m
//  Hello iOS
//
//  Created by huangxiong on 14-6-23.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    NSLog(@"%@", @"Redman 启动了应用程序！");
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    NSLog(@"%@", @"应用程序从活动状态转到非活动状态");
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    NSLog(@"%@", @"应用程序进入后台");
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    NSLog(@"%@", @"应用程序进入前台");
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    NSLog(@"%@", @"应用程序进入前台并处于活动状态");
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    NSLog(@"%@", @"应用程序终止");
}

// Save application state
-(BOOL) application:(UIApplication *)application shouldSaveApplicationState:(NSCoder *)coder
{
    return YES;
}

// Restore application state
-(BOOL) application:(UIApplication *)application shouldRestoreApplicationState:(NSCoder *)coder
{
    return  YES;
}

// Encoding restorable state
-(void) application:(UIApplication *)application willEncodeRestorableStateWithCoder:(NSCoder *)coder
{
    [coder encodeFloat: 2.0 forKey: @"Version"];
}

// Decoding restorable state
-(void) application:(UIApplication *)application didDecodeRestorableStateWithCoder:(NSCoder *)coder
{
    float lastVer = [coder decodeFloatForKey: @"Version"];
    NSLog(@"lastVer = %f", lastVer);
}

@end
