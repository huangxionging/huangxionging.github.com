//
//  ViewController.h
//  DataPicker
//
//  Created by huangxiong on 14-7-4.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;


@property (weak, nonatomic) IBOutlet UILabel *label;

- (IBAction)onClick:(id)sender;

@end
