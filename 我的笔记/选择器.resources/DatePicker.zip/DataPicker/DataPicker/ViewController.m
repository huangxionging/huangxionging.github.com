//
//  ViewController.m
//  DataPicker
//
//  Created by huangxiong on 14-7-4.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClick:(id)sender
{
    NSDate  *date = self.datePicker.date;
    NSLog(@"the date picked is: %@", [date descriptionWithLocale: [NSLocale currentLocale]]);
    
    NSDateFormatter *setDateFormatter = [[NSDateFormatter alloc]init];
    
    [setDateFormatter setDateFormat: @"YYYY-MM-dd HH:MM:SS"];
    
    NSLog(@"the date formatter is %@", [setDateFormatter stringFromDate: date]);
    
    self.label.text = [setDateFormatter stringFromDate: date];
    
    
}
@end
