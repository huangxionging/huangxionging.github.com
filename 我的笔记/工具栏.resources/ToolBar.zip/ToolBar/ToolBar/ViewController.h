//
//  ViewController.h
//  ToolBar
//
//  Created by huangxiong on 14-7-3.
//  Copyright (c) 2014年 New-Life. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *label;

- (IBAction) save:(id)sender;
- (IBAction) open:(id)sender;
@end
